﻿var objetoBoot = new Object();
objetoBoot.DivSite = "#conteudoBoot";
objetoBoot.listaBoots = [];

class Boot {
    constructor(window, $) {
        this._window = window;
        this._jquery = $;
    }

    inicilizarClasse(id, idDiv) {
        this.id = id;
        this.idDiv = idDiv;
        this.CriaBoot(this);
    }

    CriaBoot(Boot) {
        var divBoot = $("<div>").attr({ id: Boot.id, class: "col-md-3 classDivBoot" });
        $(objetoBoot.DivSite).append(divBoot);
    }
}

function AdicionarFuncaoBotao() {
    $("#AdicionarBoot").click(function () {
        AdicionarBoot(1, "div_1");
    });

    $("#LimparBoot").click(function () {
        $(objetoBoot.DivSite).html("");
    });
}


function AdicionarBoot(id, idDiv) {
    var idClasse = objetoBoot.listaBoots.push(new Boot(window, jQuery, id, idDiv)) - 1;
    objetoBoot.listaBoots[idClasse].inicilizarClasse(id, idDiv);
}



$(function () {
    AdicionarFuncaoBotao();
});